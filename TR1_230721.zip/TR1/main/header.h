#ifndef HEADER_H
#define HEADER_H

#include <Servo.h>
#include <PS2X_lib.h>

// movement
int pwm1 = A0;
int pwm2 = A1;
int pwm3 = A2;
int pwm4 = A3;
int dir1 = 10;
int dir2 = 11;
int dir3 = 12;
int dir4 = 13;
void SetupMovement();
void Direction(int, int, int, int);
void Speed (int, int, int, int);
void DetermineDirection();
void Stop();
void Up();
void Down();
void Left();
void Right();
void TurnClockwise();
void TurnCClockwise();

// ps2controller
PS2X ps2x;
int error = 0;
byte type = 0;
byte vibrate = 0;
int renew = 0;
int nJoyRy;
int nJoyRx;
int nJoyLy;
int nJoyLx;
void SetupPS2X();
void DetectPS2X();
void ReadJoystick();
void PrintJoystickValues();

// rpi2arduino
int cvValue = 0;
String rpiMsg = "";
int aim = 0;
void ReadSerialPort();
void LockOn();

// catapult
int catapultCurrentState = LOW;
int catapultPWM = 5; //pin 5 as pwm, to control speed
int catapultDIR = 6;
int catapultFire = 0;
void SetupCatapult();
void CatapultShoot();

// reload
int touchPin = 2;
int inputPin = 8;  // connect digital I/O 4 to the ECHO/Rx Pin
int outputPin = 9; // connect digital I/O 5 to the TRIG/TX Pin
int reloadCounter =0;
int reloadDir = 1;
bool reloadFlag = 1;
unsigned long usDistance;
int reloadTime = 2400;
void SetupReload();
void Reload();
void Ultrasonic();
void ReloadLeft();
void ReloadRight();
void NoReload();

// gripper
Servo gripper1;
Servo gripper2;
Servo gripper3;
Servo gripper4;
Servo gripper5;
int grab = 0;
void SetupGripper();
void GrabArrows();

#endif
