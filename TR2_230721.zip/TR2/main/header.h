#ifndef HEADER_H
#define HEADER_H

#include <Servo.h>
#include <PS2X_lib.h>

// movement
int pwm1 = A0;
int pwm2 = A1;
int pwm3 = A2;
int pwm4 = A3;
int dir1 = 10;
int dir2 = 11;
int dir3 = 12;
int dir4 = 13;
void SetupMovement();
void Direction(int, int, int, int);
void Speed (int, int, int, int);
void DetermineDirection();
void Stop();
void Up();
void Down();
void Left();
void Right();
void TurnClockwise();
void TurnCClockwise();

// ps2controller
PS2X ps2x;
int error = 0;
byte type = 0;
byte vibrate = 0;
int renew = 0;
int nJoyRy;
int nJoyRx;
int nJoyLy;
int nJoyLx;
void SetupPS2X();
void DetectPS2X();
void ReadJoystick();
void PrintJoystickValues();
/*
// rpi2arduino
int cvValue = 0;
String rpiMsg = "";
int aim = 0;
void ReadSerialPort();
void LockOn();
int blowpipeCounter = 0;
int range [5][2] {{20, -20}, {20, -20}, {20, -20}, {20, -20}, {20, -20}};
*/
// blowpipe
void SetupBlowpipe();
void Blowpipe();

// gripper
Servo gripper1;
Servo gripper2;
Servo gripper3;
Servo gripper4;
Servo gripper5;
int grab = 0;
void SetupGripper();
void GrabArrows();

#endif
